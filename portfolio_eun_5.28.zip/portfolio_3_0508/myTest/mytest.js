$("li").one("dblclick", function(){
    console.log("딱 한 번만 이벤트를 들음");
})